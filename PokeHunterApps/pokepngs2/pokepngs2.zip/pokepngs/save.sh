for((i=0;i<160;i++));do
echo http://s.pokeuniv.com/go/pokemon/$i.png
wget http://s.pokeuniv.com/go/pokemon/$i.png
done
